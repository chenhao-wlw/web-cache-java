package com.cache.alert;

/**
 * 告警级别
 */
public enum AlertLevel {
    INFO,
    WARNING,
    CRITICAL
}
