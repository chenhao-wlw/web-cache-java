package com.cache.core;

/**
 * 缓存操作类型枚举
 */
public enum CacheOperation {
    GET,
    PUT,
    DELETE
}
